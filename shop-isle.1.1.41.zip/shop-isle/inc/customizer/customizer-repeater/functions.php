<?php
/**
 * Functions for Repeater control
 *
 * @package Shop Isle
 */

/**
 * Require the script
 */
require get_template_directory() . '/inc/customizer/customizer-repeater/inc/customizer.php';
