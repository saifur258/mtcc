== ShopIsle ==

Images sources:

 * slide1.jpg: https://download.unsplash.com/uploads/141172692104151d94dd4/4f900e54
 * slide2.jpg: https://download.unsplash.com/photo-1434056886845-dac89ffe9b56
 * slide3.jpg: https://download.unsplash.com/reserve/RONyPwknRQOO3ag4xf3R_Kinsey.jpg


 * banner1.jpg: https://download.unsplash.com/photo-1433826672293-6fdc46138e66
 * banner2.jpg: https://download.unsplash.com/photo-1433643667043-663b34a5c052
 * banner3.jpg: https://download.unsplash.com/photo-1435070872030-a8113da23691
 
 * 404.jpg: https://download.unsplash.com/photo-1428895009712-de9e58a18409
 
 * team1.jpg: https://download.unsplash.com/reserve/ysPfhVSzSP2m629CW0mw_selfPortrait.jpg
 * team2.jpg: https://download.unsplash.com/photo-1433615988899-12bdf1bd42b6
 * team3.jpg: https://download.unsplash.com/photo-1427096105551-15e2512fd2dc
 * team4.jpg: https://download.unsplash.com/photo-1434123715472-19686d6cc442
 
 * background-video.jpg https://download.unsplash.com/photo-1436190807865-2e156d40f1a2
 
 * header.jpg: https://download.unsplash.com/photo-1434592370571-b4bacd3377b3
 
 * ribbon-bg.jpg: https://unsplash.com/photos/VZuLoDocz-U

 * Screenshot images:
  - https://images.unsplash.com/photo-1462804993656-fac4ff489837?ixlib=rb-0.3.5&q=80&fm=jpg&crop=entropy&s=97f0f0de387332067456ca7fdda56b7b
  - https://images.unsplash.com/photo-1469334031218-e382a71b716b?ixlib=rb-0.3.5&q=80&fm=jpg&crop=entropy&s=6423a9a76d58d977ce7b5654e955ae5f
  - https://images.unsplash.com/photo-1467838371285-0d488e371f0d?ixlib=rb-0.3.5&q=80&fm=jpg&crop=entropy&s=8fe5f9c8bccc33da8b5e6575d6e9f7a4
  - https://images.unsplash.com/photo-1469460340997-2f854421e72f?ixlib=rb-0.3.5&q=80&fm=jpg&crop=entropy&s=3f23e6dac64214e7c693810058aae58f
  - https://images.unsplash.com/photo-1414202251636-d05ac44c0182?ixlib=rb-0.3.5&q=80&fm=jpg&crop=entropy&s=95dd8c65b835464f99ae974dafe90b24
  - https://images.unsplash.com/photo-1439433547555-1f4f96513499?ixlib=rb-0.3.5&q=80&fm=jpg&crop=entropy&s=467ca3b6420d16b68015006c77421e3b
  - https://images.unsplash.com/photo-1456379771252-03388b5adf1a?ixlib=rb-0.3.5&q=80&fm=jpg&crop=entropy&s=16db1495560136a1278a6e258ac7127a

License: All unsplash.com images are licensed under the terms of the Creative Commons Zero, http://creativecommons.org/publicdomain/zero/1.0/ 	

ElegantIcons License: GPL 2.0 and MIT http://www.gnu.org/licenses/gpl-2.0.html, http://opensource.org/licenses/MIT

* Bootstrap
Resource URI: http://getbootstrap.com/
Copyright: 2011-2014 Twitter, Inc
License: MIT
License URI: http://opensource.org/licenses/MIT

* OwlCarousel 2.1.6
Copyright: 2013 Bartosz Wojciechowski, David Deutsch
Resource URI: https://owlcarousel2.github.io
License: MIT
License URI: http://opensource.org/licenses/MIT

* SmoothScroll
Copyright: Balazs Galambosi
Resource URI: http://www.owlgraphic.com/owlcarousel/
License: MIT
License URI: http://opensource.org/licenses/MIT

* jquery.mb.YTPlayer
Copyright (c) 2001-2016. Matteo Bicocchi (Pupunzi)
Resource URI: https://github.com/pupunzi/jquery.mb.YTPlayer
Licenses: MIT, GPL
Licenses URI: http://opensource.org/licenses/MIT
              http://www.gnu.org/licenses/gpl.html

* jquery.magnific-popup
Copyright (c) 2013 Dmitry Semenov
Resource URI: http://dimsemenov.com/plugins/magnific-popup/
License: MIT
License URI: http://opensource.org/licenses/MIT

* FlexSlider
Copyright 2012 WooThemes
Resource URI: https://www.woothemes.com/flexslider/
License: MIT
License URI: http://opensource.org/licenses/MIT

* FitVids.js
Copyright 2013, Chris Coyier - http://css-tricks.com + Dave Rupert - http://daverupert.com
Resource URI: http://fitvidsjs.com/
License: WTFPL
License URI: http://sam.zoy.org/wtfpl/

* jqBootstrapValidation
Resource URI: http://ReactiveRaven.github.com/jqBootstrapValidation/
License: MIT
License URI: http://opensource.org/licenses/MIT

* animate.css
Copyright (c) 2013 Daniel Eden
Resource URI: http://daneden.me/animate
License: MIT
License URI: http://opensource.org/licenses/MIT

* Customizer Range Value Control
Copyright (c) 2016 Per Soderlind
Resource URI: https://github.com/soderlind/class-customizer-range-value-control
License: GPL
License URI: http://www.gnu.org/licenses/gpl.html

* Customizer Alpha Color Picker
Copyright (c) 2015 Braad Martin
Resource URI: https://github.com/BraadMartin/components
License: GPL
License URI: http://www.gnu.org/licenses/gpl.html
